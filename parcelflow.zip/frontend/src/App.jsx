import React from "react";

export default function App() {
  return (
    <div style={{ fontFamily: "sans-serif", textAlign: "center", marginTop: 50 }}>
      <h1>📦 ParcelFlow</h1>
      <p>Volg al je pakketten op één plek!</p>
      <p>Backend status: <a href="https://parcelflow-backend.azurewebsites.net" target="_blank">check hier</a></p>
    </div>
  );
}
